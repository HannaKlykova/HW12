/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 493.0, "minX": 0.0, "maxY": 4275.0, "series": [{"data": [[0.0, 493.0], [0.1, 493.0], [0.2, 493.0], [0.3, 493.0], [0.4, 495.0], [0.5, 501.0], [0.6, 501.0], [0.7, 502.0], [0.8, 505.0], [0.9, 505.0], [1.0, 509.0], [1.1, 529.0], [1.2, 529.0], [1.3, 533.0], [1.4, 536.0], [1.5, 536.0], [1.6, 577.0], [1.7, 590.0], [1.8, 590.0], [1.9, 590.0], [2.0, 593.0], [2.1, 593.0], [2.2, 594.0], [2.3, 595.0], [2.4, 595.0], [2.5, 595.0], [2.6, 597.0], [2.7, 597.0], [2.8, 598.0], [2.9, 598.0], [3.0, 598.0], [3.1, 599.0], [3.2, 601.0], [3.3, 601.0], [3.4, 601.0], [3.5, 601.0], [3.6, 601.0], [3.7, 613.0], [3.8, 614.0], [3.9, 614.0], [4.0, 619.0], [4.1, 621.0], [4.2, 621.0], [4.3, 622.0], [4.4, 626.0], [4.5, 626.0], [4.6, 626.0], [4.7, 626.0], [4.8, 626.0], [4.9, 632.0], [5.0, 640.0], [5.1, 640.0], [5.2, 642.0], [5.3, 644.0], [5.4, 644.0], [5.5, 648.0], [5.6, 649.0], [5.7, 649.0], [5.8, 651.0], [5.9, 651.0], [6.0, 652.0], [6.1, 653.0], [6.2, 653.0], [6.3, 661.0], [6.4, 662.0], [6.5, 662.0], [6.6, 676.0], [6.7, 717.0], [6.8, 717.0], [6.9, 722.0], [7.0, 730.0], [7.1, 730.0], [7.2, 732.0], [7.3, 733.0], [7.4, 733.0], [7.5, 744.0], [7.6, 752.0], [7.7, 752.0], [7.8, 755.0], [7.9, 761.0], [8.0, 761.0], [8.1, 761.0], [8.2, 762.0], [8.3, 762.0], [8.4, 784.0], [8.5, 795.0], [8.6, 795.0], [8.7, 798.0], [8.8, 815.0], [8.9, 815.0], [9.0, 816.0], [9.1, 819.0], [9.2, 819.0], [9.3, 826.0], [9.4, 834.0], [9.5, 834.0], [9.6, 836.0], [9.7, 836.0], [9.8, 836.0], [9.9, 845.0], [10.0, 851.0], [10.1, 851.0], [10.2, 851.0], [10.3, 853.0], [10.4, 853.0], [10.5, 853.0], [10.6, 854.0], [10.7, 854.0], [10.8, 855.0], [10.9, 855.0], [11.0, 855.0], [11.1, 860.0], [11.2, 867.0], [11.3, 867.0], [11.4, 874.0], [11.5, 887.0], [11.6, 887.0], [11.7, 888.0], [11.8, 888.0], [11.9, 890.0], [12.0, 899.0], [12.1, 899.0], [12.2, 901.0], [12.3, 902.0], [12.4, 902.0], [12.5, 905.0], [12.6, 909.0], [12.7, 909.0], [12.8, 913.0], [12.9, 913.0], [13.0, 913.0], [13.1, 914.0], [13.2, 915.0], [13.3, 915.0], [13.4, 918.0], [13.5, 921.0], [13.6, 921.0], [13.7, 925.0], [13.8, 931.0], [13.9, 931.0], [14.0, 933.0], [14.1, 934.0], [14.2, 934.0], [14.3, 934.0], [14.4, 934.0], [14.5, 934.0], [14.6, 936.0], [14.7, 938.0], [14.8, 938.0], [14.9, 942.0], [15.0, 943.0], [15.1, 943.0], [15.2, 943.0], [15.3, 945.0], [15.4, 945.0], [15.5, 946.0], [15.6, 947.0], [15.7, 947.0], [15.8, 948.0], [15.9, 949.0], [16.0, 949.0], [16.1, 951.0], [16.2, 952.0], [16.3, 952.0], [16.4, 956.0], [16.5, 961.0], [16.6, 961.0], [16.7, 962.0], [16.8, 967.0], [16.9, 967.0], [17.0, 967.0], [17.1, 969.0], [17.2, 969.0], [17.3, 971.0], [17.4, 971.0], [17.5, 971.0], [17.6, 971.0], [17.7, 971.0], [17.8, 974.0], [17.9, 974.0], [18.0, 974.0], [18.1, 975.0], [18.2, 975.0], [18.3, 975.0], [18.4, 975.0], [18.5, 975.0], [18.6, 975.0], [18.7, 976.0], [18.8, 977.0], [18.9, 977.0], [19.0, 978.0], [19.1, 978.0], [19.2, 978.0], [19.3, 979.0], [19.4, 980.0], [19.5, 980.0], [19.6, 981.0], [19.7, 982.0], [19.8, 982.0], [19.9, 982.0], [20.0, 983.0], [20.1, 983.0], [20.2, 983.0], [20.3, 984.0], [20.4, 984.0], [20.5, 984.0], [20.6, 985.0], [20.7, 985.0], [20.8, 985.0], [20.9, 986.0], [21.0, 986.0], [21.1, 986.0], [21.2, 986.0], [21.3, 986.0], [21.4, 986.0], [21.5, 988.0], [21.6, 988.0], [21.7, 988.0], [21.8, 988.0], [21.9, 988.0], [22.0, 988.0], [22.1, 988.0], [22.2, 988.0], [22.3, 989.0], [22.4, 990.0], [22.5, 990.0], [22.6, 990.0], [22.7, 990.0], [22.8, 990.0], [22.9, 990.0], [23.0, 991.0], [23.1, 991.0], [23.2, 992.0], [23.3, 992.0], [23.4, 992.0], [23.5, 993.0], [23.6, 993.0], [23.7, 993.0], [23.8, 993.0], [23.9, 993.0], [24.0, 994.0], [24.1, 996.0], [24.2, 996.0], [24.3, 997.0], [24.4, 998.0], [24.5, 998.0], [24.6, 998.0], [24.7, 999.0], [24.8, 999.0], [24.9, 999.0], [25.0, 1000.0], [25.1, 1000.0], [25.2, 1001.0], [25.3, 1002.0], [25.4, 1002.0], [25.5, 1003.0], [25.6, 1004.0], [25.7, 1004.0], [25.8, 1006.0], [25.9, 1009.0], [26.0, 1009.0], [26.1, 1010.0], [26.2, 1011.0], [26.3, 1011.0], [26.4, 1011.0], [26.5, 1012.0], [26.6, 1012.0], [26.7, 1012.0], [26.8, 1013.0], [26.9, 1013.0], [27.0, 1014.0], [27.1, 1014.0], [27.2, 1014.0], [27.3, 1015.0], [27.4, 1016.0], [27.5, 1016.0], [27.6, 1017.0], [27.7, 1018.0], [27.8, 1018.0], [27.9, 1020.0], [28.0, 1021.0], [28.1, 1021.0], [28.2, 1021.0], [28.3, 1021.0], [28.4, 1021.0], [28.5, 1022.0], [28.6, 1023.0], [28.7, 1023.0], [28.8, 1024.0], [28.9, 1026.0], [29.0, 1026.0], [29.1, 1027.0], [29.2, 1027.0], [29.3, 1027.0], [29.4, 1029.0], [29.5, 1029.0], [29.6, 1029.0], [29.7, 1030.0], [29.8, 1030.0], [29.9, 1031.0], [30.0, 1032.0], [30.1, 1032.0], [30.2, 1033.0], [30.3, 1033.0], [30.4, 1033.0], [30.5, 1036.0], [30.6, 1036.0], [30.7, 1036.0], [30.8, 1036.0], [30.9, 1037.0], [31.0, 1037.0], [31.1, 1037.0], [31.2, 1038.0], [31.3, 1038.0], [31.4, 1038.0], [31.5, 1039.0], [31.6, 1039.0], [31.7, 1039.0], [31.8, 1041.0], [31.9, 1041.0], [32.0, 1042.0], [32.1, 1043.0], [32.2, 1043.0], [32.3, 1043.0], [32.4, 1044.0], [32.5, 1044.0], [32.6, 1044.0], [32.7, 1044.0], [32.8, 1044.0], [32.9, 1046.0], [33.0, 1046.0], [33.1, 1046.0], [33.2, 1062.0], [33.3, 1063.0], [33.4, 1063.0], [33.5, 1065.0], [33.6, 1066.0], [33.7, 1066.0], [33.8, 1066.0], [33.9, 1067.0], [34.0, 1067.0], [34.1, 1067.0], [34.2, 1068.0], [34.3, 1068.0], [34.4, 1070.0], [34.5, 1071.0], [34.6, 1071.0], [34.7, 1071.0], [34.8, 1073.0], [34.9, 1073.0], [35.0, 1075.0], [35.1, 1079.0], [35.2, 1079.0], [35.3, 1079.0], [35.4, 1079.0], [35.5, 1080.0], [35.6, 1083.0], [35.7, 1083.0], [35.8, 1083.0], [35.9, 1083.0], [36.0, 1083.0], [36.1, 1084.0], [36.2, 1085.0], [36.3, 1085.0], [36.4, 1085.0], [36.5, 1086.0], [36.6, 1086.0], [36.7, 1086.0], [36.8, 1086.0], [36.9, 1086.0], [37.0, 1087.0], [37.1, 1087.0], [37.2, 1087.0], [37.3, 1087.0], [37.4, 1089.0], [37.5, 1089.0], [37.6, 1089.0], [37.7, 1089.0], [37.8, 1089.0], [37.9, 1089.0], [38.0, 1094.0], [38.1, 1094.0], [38.2, 1094.0], [38.3, 1099.0], [38.4, 1099.0], [38.5, 1099.0], [38.6, 1100.0], [38.7, 1100.0], [38.8, 1102.0], [38.9, 1103.0], [39.0, 1103.0], [39.1, 1105.0], [39.2, 1119.0], [39.3, 1119.0], [39.4, 1121.0], [39.5, 1123.0], [39.6, 1123.0], [39.7, 1124.0], [39.8, 1124.0], [39.9, 1124.0], [40.0, 1127.0], [40.1, 1129.0], [40.2, 1129.0], [40.3, 1130.0], [40.4, 1130.0], [40.5, 1130.0], [40.6, 1132.0], [40.7, 1132.0], [40.8, 1132.0], [40.9, 1136.0], [41.0, 1136.0], [41.1, 1136.0], [41.2, 1136.0], [41.3, 1136.0], [41.4, 1138.0], [41.5, 1140.0], [41.6, 1140.0], [41.7, 1140.0], [41.8, 1141.0], [41.9, 1141.0], [42.0, 1143.0], [42.1, 1144.0], [42.2, 1144.0], [42.3, 1144.0], [42.4, 1145.0], [42.5, 1145.0], [42.6, 1145.0], [42.7, 1147.0], [42.8, 1147.0], [42.9, 1155.0], [43.0, 1157.0], [43.1, 1157.0], [43.2, 1159.0], [43.3, 1160.0], [43.4, 1160.0], [43.5, 1161.0], [43.6, 1163.0], [43.7, 1163.0], [43.8, 1163.0], [43.9, 1164.0], [44.0, 1164.0], [44.1, 1166.0], [44.2, 1167.0], [44.3, 1167.0], [44.4, 1168.0], [44.5, 1172.0], [44.6, 1172.0], [44.7, 1175.0], [44.8, 1178.0], [44.9, 1178.0], [45.0, 1179.0], [45.1, 1179.0], [45.2, 1179.0], [45.3, 1180.0], [45.4, 1180.0], [45.5, 1180.0], [45.6, 1182.0], [45.7, 1183.0], [45.8, 1183.0], [45.9, 1185.0], [46.0, 1187.0], [46.1, 1187.0], [46.2, 1187.0], [46.3, 1188.0], [46.4, 1188.0], [46.5, 1188.0], [46.6, 1189.0], [46.7, 1189.0], [46.8, 1190.0], [46.9, 1191.0], [47.0, 1191.0], [47.1, 1195.0], [47.2, 1195.0], [47.3, 1196.0], [47.4, 1197.0], [47.5, 1197.0], [47.6, 1197.0], [47.7, 1199.0], [47.8, 1199.0], [47.9, 1200.0], [48.0, 1201.0], [48.1, 1201.0], [48.2, 1201.0], [48.3, 1203.0], [48.4, 1203.0], [48.5, 1204.0], [48.6, 1204.0], [48.7, 1204.0], [48.8, 1206.0], [48.9, 1207.0], [49.0, 1207.0], [49.1, 1207.0], [49.2, 1207.0], [49.3, 1207.0], [49.4, 1209.0], [49.5, 1210.0], [49.6, 1210.0], [49.7, 1210.0], [49.8, 1212.0], [49.9, 1212.0], [50.0, 1217.0], [50.1, 1218.0], [50.2, 1218.0], [50.3, 1226.0], [50.4, 1230.0], [50.5, 1230.0], [50.6, 1231.0], [50.7, 1232.0], [50.8, 1232.0], [50.9, 1232.0], [51.0, 1235.0], [51.1, 1235.0], [51.2, 1237.0], [51.3, 1238.0], [51.4, 1238.0], [51.5, 1245.0], [51.6, 1245.0], [51.7, 1245.0], [51.8, 1247.0], [51.9, 1247.0], [52.0, 1247.0], [52.1, 1248.0], [52.2, 1248.0], [52.3, 1248.0], [52.4, 1249.0], [52.5, 1250.0], [52.6, 1250.0], [52.7, 1250.0], [52.8, 1251.0], [52.9, 1251.0], [53.0, 1252.0], [53.1, 1252.0], [53.2, 1254.0], [53.3, 1261.0], [53.4, 1261.0], [53.5, 1263.0], [53.6, 1264.0], [53.7, 1264.0], [53.8, 1265.0], [53.9, 1265.0], [54.0, 1265.0], [54.1, 1266.0], [54.2, 1266.0], [54.3, 1266.0], [54.4, 1267.0], [54.5, 1267.0], [54.6, 1267.0], [54.7, 1268.0], [54.8, 1268.0], [54.9, 1268.0], [55.0, 1268.0], [55.1, 1268.0], [55.2, 1268.0], [55.3, 1268.0], [55.4, 1269.0], [55.5, 1269.0], [55.6, 1269.0], [55.7, 1270.0], [55.8, 1270.0], [55.9, 1270.0], [56.0, 1271.0], [56.1, 1271.0], [56.2, 1272.0], [56.3, 1272.0], [56.4, 1272.0], [56.5, 1272.0], [56.6, 1273.0], [56.7, 1273.0], [56.8, 1274.0], [56.9, 1275.0], [57.0, 1275.0], [57.1, 1277.0], [57.2, 1278.0], [57.3, 1278.0], [57.4, 1278.0], [57.5, 1279.0], [57.6, 1279.0], [57.7, 1281.0], [57.8, 1282.0], [57.9, 1282.0], [58.0, 1289.0], [58.1, 1291.0], [58.2, 1291.0], [58.3, 1296.0], [58.4, 1303.0], [58.5, 1303.0], [58.6, 1329.0], [58.7, 1331.0], [58.8, 1331.0], [58.9, 1332.0], [59.0, 1332.0], [59.1, 1332.0], [59.2, 1336.0], [59.3, 1336.0], [59.4, 1342.0], [59.5, 1343.0], [59.6, 1343.0], [59.7, 1343.0], [59.8, 1347.0], [59.9, 1347.0], [60.0, 1349.0], [60.1, 1350.0], [60.2, 1350.0], [60.3, 1351.0], [60.4, 1352.0], [60.5, 1352.0], [60.6, 1353.0], [60.7, 1353.0], [60.8, 1353.0], [60.9, 1354.0], [61.0, 1354.0], [61.1, 1354.0], [61.2, 1354.0], [61.3, 1357.0], [61.4, 1357.0], [61.5, 1361.0], [61.6, 1361.0], [61.7, 1361.0], [61.8, 1362.0], [61.9, 1362.0], [62.0, 1362.0], [62.1, 1362.0], [62.2, 1363.0], [62.3, 1363.0], [62.4, 1365.0], [62.5, 1365.0], [62.6, 1365.0], [62.7, 1365.0], [62.8, 1389.0], [62.9, 1389.0], [63.0, 1390.0], [63.1, 1391.0], [63.2, 1391.0], [63.3, 1391.0], [63.4, 1393.0], [63.5, 1393.0], [63.6, 1393.0], [63.7, 1397.0], [63.8, 1397.0], [63.9, 1398.0], [64.0, 1399.0], [64.1, 1399.0], [64.2, 1401.0], [64.3, 1403.0], [64.4, 1403.0], [64.5, 1405.0], [64.6, 1410.0], [64.7, 1410.0], [64.8, 1411.0], [64.9, 1411.0], [65.0, 1411.0], [65.1, 1419.0], [65.2, 1419.0], [65.3, 1428.0], [65.4, 1430.0], [65.5, 1430.0], [65.6, 1431.0], [65.7, 1433.0], [65.8, 1433.0], [65.9, 1435.0], [66.0, 1437.0], [66.1, 1437.0], [66.2, 1437.0], [66.3, 1444.0], [66.4, 1444.0], [66.5, 1444.0], [66.6, 1448.0], [66.7, 1448.0], [66.8, 1450.0], [66.9, 1450.0], [67.0, 1450.0], [67.1, 1459.0], [67.2, 1460.0], [67.3, 1460.0], [67.4, 1460.0], [67.5, 1461.0], [67.6, 1461.0], [67.7, 1461.0], [67.8, 1462.0], [67.9, 1462.0], [68.0, 1462.0], [68.1, 1462.0], [68.2, 1462.0], [68.3, 1463.0], [68.4, 1463.0], [68.5, 1463.0], [68.6, 1463.0], [68.7, 1464.0], [68.8, 1464.0], [68.9, 1469.0], [69.0, 1469.0], [69.1, 1469.0], [69.2, 1470.0], [69.3, 1472.0], [69.4, 1472.0], [69.5, 1483.0], [69.6, 1483.0], [69.7, 1483.0], [69.8, 1489.0], [69.9, 1492.0], [70.0, 1492.0], [70.1, 1494.0], [70.2, 1496.0], [70.3, 1496.0], [70.4, 1500.0], [70.5, 1500.0], [70.6, 1500.0], [70.7, 1502.0], [70.8, 1502.0], [70.9, 1507.0], [71.0, 1508.0], [71.1, 1508.0], [71.2, 1509.0], [71.3, 1509.0], [71.4, 1509.0], [71.5, 1511.0], [71.6, 1518.0], [71.7, 1518.0], [71.8, 1522.0], [71.9, 1522.0], [72.0, 1522.0], [72.1, 1530.0], [72.2, 1560.0], [72.3, 1560.0], [72.4, 1564.0], [72.5, 1565.0], [72.6, 1565.0], [72.7, 1565.0], [72.8, 1571.0], [72.9, 1571.0], [73.0, 1572.0], [73.1, 1595.0], [73.2, 1595.0], [73.3, 1598.0], [73.4, 1603.0], [73.5, 1603.0], [73.6, 1605.0], [73.7, 1605.0], [73.8, 1605.0], [73.9, 1605.0], [74.0, 1607.0], [74.1, 1607.0], [74.2, 1607.0], [74.3, 1624.0], [74.4, 1624.0], [74.5, 1633.0], [74.6, 1633.0], [74.7, 1633.0], [74.8, 1634.0], [74.9, 1636.0], [75.0, 1636.0], [75.1, 1766.0], [75.2, 1784.0], [75.3, 1784.0], [75.4, 1844.0], [75.5, 1861.0], [75.6, 1861.0], [75.7, 1862.0], [75.8, 1862.0], [75.9, 1862.0], [76.0, 1864.0], [76.1, 1865.0], [76.2, 1865.0], [76.3, 1870.0], [76.4, 1872.0], [76.5, 1872.0], [76.6, 1887.0], [76.7, 1887.0], [76.8, 1900.0], [76.9, 1955.0], [77.0, 1955.0], [77.1, 1955.0], [77.2, 1958.0], [77.3, 1958.0], [77.4, 1964.0], [77.5, 1965.0], [77.6, 1965.0], [77.7, 1965.0], [77.8, 1996.0], [77.9, 1996.0], [78.0, 2005.0], [78.1, 2005.0], [78.2, 2005.0], [78.3, 2057.0], [78.4, 2062.0], [78.5, 2062.0], [78.6, 2064.0], [78.7, 2066.0], [78.8, 2066.0], [78.9, 2067.0], [79.0, 2067.0], [79.1, 2067.0], [79.2, 2070.0], [79.3, 2072.0], [79.4, 2072.0], [79.5, 2076.0], [79.6, 2088.0], [79.7, 2088.0], [79.8, 2089.0], [79.9, 2090.0], [80.0, 2090.0], [80.1, 2096.0], [80.2, 2096.0], [80.3, 2096.0], [80.4, 2099.0], [80.5, 2099.0], [80.6, 2099.0], [80.7, 2099.0], [80.8, 2101.0], [80.9, 2101.0], [81.0, 2105.0], [81.1, 2107.0], [81.2, 2107.0], [81.3, 2113.0], [81.4, 2115.0], [81.5, 2115.0], [81.6, 2115.0], [81.7, 2117.0], [81.8, 2117.0], [81.9, 2118.0], [82.0, 2121.0], [82.1, 2121.0], [82.2, 2130.0], [82.3, 2130.0], [82.4, 2130.0], [82.5, 2133.0], [82.6, 2133.0], [82.7, 2142.0], [82.8, 2151.0], [82.9, 2151.0], [83.0, 2151.0], [83.1, 2155.0], [83.2, 2155.0], [83.3, 2156.0], [83.4, 2158.0], [83.5, 2158.0], [83.6, 2159.0], [83.7, 2163.0], [83.8, 2163.0], [83.9, 2166.0], [84.0, 2169.0], [84.1, 2169.0], [84.2, 2169.0], [84.3, 2175.0], [84.4, 2175.0], [84.5, 2229.0], [84.6, 2257.0], [84.7, 2257.0], [84.8, 2262.0], [84.9, 2264.0], [85.0, 2264.0], [85.1, 2268.0], [85.2, 2269.0], [85.3, 2269.0], [85.4, 2269.0], [85.5, 2272.0], [85.6, 2272.0], [85.7, 2275.0], [85.8, 2280.0], [85.9, 2280.0], [86.0, 2285.0], [86.1, 2288.0], [86.2, 2288.0], [86.3, 2291.0], [86.4, 2293.0], [86.5, 2293.0], [86.6, 2293.0], [86.7, 2293.0], [86.8, 2293.0], [86.9, 2295.0], [87.0, 2295.0], [87.1, 2295.0], [87.2, 2296.0], [87.3, 2296.0], [87.4, 2296.0], [87.5, 2297.0], [87.6, 2321.0], [87.7, 2321.0], [87.8, 2323.0], [87.9, 2324.0], [88.0, 2324.0], [88.1, 2324.0], [88.2, 2325.0], [88.3, 2325.0], [88.4, 2325.0], [88.5, 2325.0], [88.6, 2325.0], [88.7, 2329.0], [88.8, 2329.0], [88.9, 2329.0], [89.0, 2330.0], [89.1, 2330.0], [89.2, 2330.0], [89.3, 2332.0], [89.4, 2332.0], [89.5, 2332.0], [89.6, 2334.0], [89.7, 2334.0], [89.8, 2339.0], [89.9, 2341.0], [90.0, 2341.0], [90.1, 2348.0], [90.2, 2356.0], [90.3, 2356.0], [90.4, 2357.0], [90.5, 2358.0], [90.6, 2358.0], [90.7, 2366.0], [90.8, 2421.0], [90.9, 2421.0], [91.0, 2443.0], [91.1, 2455.0], [91.2, 2455.0], [91.3, 2465.0], [91.4, 2465.0], [91.5, 2465.0], [91.6, 2465.0], [91.7, 2466.0], [91.8, 2466.0], [91.9, 2467.0], [92.0, 2469.0], [92.1, 2469.0], [92.2, 2470.0], [92.3, 2471.0], [92.4, 2471.0], [92.5, 2472.0], [92.6, 2472.0], [92.7, 2472.0], [92.8, 2473.0], [92.9, 2474.0], [93.0, 2474.0], [93.1, 2474.0], [93.2, 2476.0], [93.3, 2476.0], [93.4, 2494.0], [93.5, 2496.0], [93.6, 2496.0], [93.7, 2497.0], [93.8, 2504.0], [93.9, 2504.0], [94.0, 2618.0], [94.1, 2752.0], [94.2, 2752.0], [94.3, 2772.0], [94.4, 2772.0], [94.5, 2888.0], [94.6, 2903.0], [94.7, 2903.0], [94.8, 3052.0], [94.9, 3061.0], [95.0, 3061.0], [95.1, 3061.0], [95.2, 3063.0], [95.3, 3063.0], [95.4, 3063.0], [95.5, 3063.0], [95.6, 3063.0], [95.7, 3063.0], [95.8, 3064.0], [95.9, 3064.0], [96.0, 3064.0], [96.1, 3065.0], [96.2, 3065.0], [96.3, 3066.0], [96.4, 3070.0], [96.5, 3070.0], [96.6, 3318.0], [96.7, 3323.0], [96.8, 3323.0], [96.9, 3329.0], [97.0, 3329.0], [97.1, 3329.0], [97.2, 3331.0], [97.3, 3331.0], [97.4, 3331.0], [97.5, 3334.0], [97.6, 3338.0], [97.7, 3338.0], [97.8, 3417.0], [97.9, 3427.0], [98.0, 3427.0], [98.1, 3429.0], [98.2, 3917.0], [98.3, 3917.0], [98.4, 3924.0], [98.5, 3927.0], [98.6, 3927.0], [98.7, 4017.0], [98.8, 4044.0], [98.9, 4044.0], [99.0, 4059.0], [99.1, 4060.0], [99.2, 4060.0], [99.3, 4060.0], [99.4, 4061.0], [99.5, 4061.0], [99.6, 4062.0], [99.7, 4273.0], [99.8, 4273.0], [99.9, 4275.0], [100.0, 4275.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 400.0, "maxY": 90.0, "series": [{"data": [[600.0, 23.0], [700.0, 14.0], [800.0, 22.0], [900.0, 85.0], [1000.0, 90.0], [1100.0, 61.0], [1200.0, 70.0], [1300.0, 38.0], [1400.0, 41.0], [1500.0, 20.0], [1600.0, 11.0], [1700.0, 2.0], [1800.0, 9.0], [1900.0, 8.0], [2000.0, 19.0], [2100.0, 24.0], [2200.0, 21.0], [2300.0, 21.0], [2400.0, 20.0], [2500.0, 1.0], [2600.0, 1.0], [2700.0, 2.0], [2800.0, 1.0], [2900.0, 1.0], [3000.0, 12.0], [3300.0, 8.0], [3400.0, 3.0], [3900.0, 3.0], [4000.0, 7.0], [4200.0, 2.0], [400.0, 3.0], [500.0, 18.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 4200.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 3.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 464.0, "series": [{"data": [[0.0, 3.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 464.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 194.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 2.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 9.414285714285715, "minX": 1.73065758E12, "maxY": 59.93231810490701, "series": [{"data": [[1.73065758E12, 59.93231810490701], [1.73065764E12, 9.414285714285715]], "isOverall": false, "label": "jp@gc - Ultimate Thread Group", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.73065764E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 7200000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 597.0, "minX": 2.0, "maxY": 4062.0, "series": [{"data": [[2.0, 900.0], [3.0, 860.0], [6.0, 768.3333333333334], [7.0, 890.0], [8.0, 816.0], [9.0, 834.0], [10.0, 1080.608695652173], [13.0, 2091.25], [14.0, 1419.857142857143], [18.0, 1404.25], [20.0, 669.0], [21.0, 1391.6666666666667], [22.0, 1393.0], [24.0, 1394.5], [27.0, 2421.0], [28.0, 3394.0], [33.0, 2329.5], [35.0, 2325.5], [34.0, 2329.0], [37.0, 2296.0], [38.0, 2345.5], [41.0, 2325.75], [42.0, 2324.0], [45.0, 2323.0], [44.0, 2324.5], [47.0, 2275.0], [46.0, 2298.4], [48.0, 2339.0], [51.0, 2269.0], [50.0, 2341.0], [53.0, 2293.0], [55.0, 2229.0], [54.0, 2257.0], [59.0, 1437.0], [60.0, 1361.0], [67.0, 1357.5], [65.0, 1358.5], [71.0, 1210.0], [70.0, 1362.0], [68.0, 1386.3333333333333], [75.0, 1280.0], [73.0, 1326.0], [79.0, 1202.6666666666667], [76.0, 1209.0], [83.0, 4062.0], [81.0, 1184.0], [80.0, 1185.0], [84.0, 4056.8], [91.0, 989.0], [88.0, 987.75], [94.0, 977.5], [92.0, 984.0], [98.0, 1979.6666666666667], [96.0, 969.0], [102.0, 1584.5], [101.0, 1607.0], [107.0, 1595.0], [106.0, 1602.6666666666667], [104.0, 1606.0], [111.0, 830.3333333333334], [110.0, 1963.6850000000006], [108.0, 2334.0], [113.0, 902.75], [118.0, 633.1666666666667], [117.0, 597.0], [116.0, 1035.5]], "isOverall": false, "label": "HTTP Request", "isController": false}, {"data": [[54.582450832072674, 1454.1739788199695]], "isOverall": false, "label": "HTTP Request-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 118.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 189.0, "minX": 1.73065758E12, "maxY": 275563.6, "series": [{"data": [[1.73065758E12, 275563.6], [1.73065764E12, 32638.666666666668]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.73065758E12, 1595.7], [1.73065764E12, 189.0]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.73065764E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 7200000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 1131.6857142857143, "minX": 1.73065758E12, "maxY": 1492.3705583756346, "series": [{"data": [[1.73065758E12, 1492.3705583756346], [1.73065764E12, 1131.6857142857143]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.73065764E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 7200000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 1036.4857142857138, "minX": 1.73065758E12, "maxY": 1312.8324873096446, "series": [{"data": [[1.73065758E12, 1312.8324873096446], [1.73065764E12, 1036.4857142857138]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.73065764E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 7200000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 182.39999999999998, "minX": 1.73065758E12, "maxY": 517.6548223350259, "series": [{"data": [[1.73065758E12, 517.6548223350259], [1.73065764E12, 182.39999999999998]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.73065764E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 7200000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 493.0, "minX": 1.73065758E12, "maxY": 4275.0, "series": [{"data": [[1.73065758E12, 4275.0], [1.73065764E12, 1766.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.73065758E12, 493.0], [1.73065764E12, 626.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.73065758E12, 2452.600000000001], [1.73065764E12, 1522.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.73065758E12, 4060.0], [1.73065764E12, 1766.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.73065758E12, 1265.0], [1.73065764E12, 1102.5]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.73065758E12, 3063.0], [1.73065764E12, 1564.45]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.73065764E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 7200000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 613.0, "minX": 1.0, "maxY": 2466.0, "series": [{"data": [[2.0, 1064.5], [9.0, 1450.0], [37.0, 613.0], [10.0, 1043.0], [43.0, 2466.0], [12.0, 1463.5], [13.0, 1039.0], [14.0, 1088.0], [1.0, 1439.5], [67.0, 2121.0], [4.0, 964.5], [17.0, 744.0], [19.0, 901.0], [5.0, 1130.0], [84.0, 1440.5], [89.0, 1270.0], [24.0, 1391.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 89.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 415.0, "minX": 1.0, "maxY": 2295.0, "series": [{"data": [[2.0, 1001.0], [9.0, 1013.0], [37.0, 415.0], [10.0, 995.5], [43.0, 2295.0], [12.0, 1385.0], [13.0, 1018.0], [14.0, 946.0], [1.0, 1200.0], [67.0, 1819.0], [4.0, 940.5], [17.0, 675.0], [19.0, 880.0], [5.0, 1088.0], [84.0, 1321.0], [89.0, 939.0], [24.0, 1270.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 89.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 1.0, "minX": 1.73065758E12, "maxY": 10.016666666666667, "series": [{"data": [[1.73065758E12, 10.016666666666667], [1.73065764E12, 1.0]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.73065764E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 7200000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 1.1666666666666667, "minX": 1.73065758E12, "maxY": 9.85, "series": [{"data": [[1.73065758E12, 9.85], [1.73065764E12, 1.1666666666666667]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.73065764E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 7200000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 1.1666666666666667, "minX": 1.73065758E12, "maxY": 9.85, "series": [{"data": [[1.73065758E12, 9.85], [1.73065764E12, 1.1666666666666667]], "isOverall": false, "label": "HTTP Request-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.73065764E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 7200000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 1.1666666666666667, "minX": 1.73065758E12, "maxY": 9.85, "series": [{"data": [[1.73065758E12, 9.85], [1.73065764E12, 1.1666666666666667]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.73065764E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 7200000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

